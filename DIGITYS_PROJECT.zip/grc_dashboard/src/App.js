import React, { useState } from "react";
import "./App.css";
import 'bootstrap/dist/css/bootstrap.min.css';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  BarChart,
  Bar,
  ResponsiveContainer,
} from "recharts";
import { FaSun, FaMoon } from "react-icons/fa";

const riskData = [
  { month: "Jan", score: 45 },
  { month: "Feb", score: 60 },
  { month: "Mar", score: 50 },
  { month: "Apr", score: 70 },
  { month: "May", score: 65 },
];

const complianceData = [
  { dept: "HR", coverage: 80 },
  { dept: "IT", coverage: 95 },
  { dept: "Finance", coverage: 70 },
  { dept: "Legal", coverage: 60 },
];

const securityAlerts = [
  { severity: "High", message: "🔴 Unauthorized Access" },
  { severity: "High", message: "🔴 Firewall Breach Attempt" },
  { severity: "Medium", message: "🟠 Outdated Software" },
  { severity: "Medium", message: "🟠 Unpatched Vulnerability Detected" },
  { severity: "Low", message: "🟢 Password Policy Violation" },
];

function App() {
  const [darkMode, setDarkMode] = useState(false);

  return (
    <div className={darkMode ? "app dark" : "app"}>
      <header>
        <h1 className="fw-bold mb-0">📊 GRC Dashboard</h1>
        <div className="mode-toggle" onClick={() => setDarkMode(!darkMode)}>
          {darkMode ? <FaSun className="sunIcon" size={28} /> : <FaMoon className="moonIcon" size={28} />}
        </div>
      </header>

      <div className="cards">
        <div className="card gradient-card">
          <h2>🔥 Risk Score</h2>
          <div className="risk-item">
            <p>🛡️ Data Privacy</p>
            <div className="progress-bar-container">
              <div className="progress-bar success" style={{ width: "72%" }}>
              </div>
              <span className="progress-value">72%</span>
            </div>
          </div>
          <div className="risk-item">
            <p>🤝 Vendor Risk</p>
            <div className="progress-bar-container">
              <div className="progress-bar danger" style={{ width: "60%" }}></div>
              <span className="progress-value">60%</span>
            </div>
          </div>
          <div className="risk-item">
            <p>🔐 Access Control</p>
            <div className="progress-bar-container">
              <div className="progress-bar warning" style={{ width: "55%" }}></div>
              <span className="progress-value">55%</span>
            </div>
          </div>
        </div>

        <div className="card gradient-card">
          <h2>✅ Compliance Status</h2>
          <div className="badge-bar">
            <span className="badge success mb-2">ISO 27001</span>
            <div className="progress-bar-container">
              <div className="progress-bar success" style={{ width: "85%" }}></div>
              <span className="progress-value">85%</span>
            </div>
          </div>
          <div className="badge-bar">
            <span className="badge warning mb-2">SOC 2</span>
            <div className="progress-bar-container">
              <div className="progress-bar warning" style={{ width: "70%" }}></div>
              <span className="progress-value">70%</span>
            </div>
          </div>
          <div className="badge-bar">
            <span className="badge danger mb-2">GDPR</span>
            <div className="progress-bar-container">
              <div className="progress-bar danger" style={{ width: "55%" }}></div>
              <span className="progress-value">55%</span>
            </div>
          </div>
        </div>

        <div className="card gradient-card">
          <h2>⚠️ Security Alerts</h2>
          <ul className="alerts-list">
            {securityAlerts.map((alert, index) => (
              <li key={index} className={`alert-item ${alert.severity.toLowerCase()}`}>
                {alert.message}
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="charts">
        <div className="chart gradient-card">
          <h2>📈 Risk Trends Over Time</h2>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={riskData}>
              <XAxis dataKey="month" />
              <YAxis domain={[0, 100]} />
              <Tooltip />
              <Line type="monotone" dataKey="score" stroke="#8884d8" strokeWidth={3} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="chart gradient-card">
          <h2>🏢 Compliance by Department</h2>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={complianceData}>
              <XAxis dataKey="dept" />
              <YAxis domain={[0, 100]} />
              <Tooltip />
              <Bar dataKey="coverage" fill="#00c49f" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

export default App;
